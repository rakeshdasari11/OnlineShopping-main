
import './App.css'
import {students} from './main.js'
function App() {



  return (
     <div> <p className='p'>STUDENTS</p>
      <div className='ad'>
     {students.map((stundet)=>(
     <div className='div'>
        <p>
          <p>{stundet.name}</p>  
          <p>{stundet.age}</p>
          <p className={stundet.scholarship?"green":""}>{stundet.scholarship?"stidendianti":"arastidendianti"}</p>  
          <p>{stundet.attend==100?"warmatebuli":stundet.attend}</p> 
          <p>{stundet.course_type}</p>
          <img src={stundet.photo}width={140} alt="" />
        </p> 
      </div> 
     ))}
     </div>
     </div>
  )
}

export default App
